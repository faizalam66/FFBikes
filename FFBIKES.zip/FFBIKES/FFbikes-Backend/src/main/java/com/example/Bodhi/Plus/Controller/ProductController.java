package com.example.Bodhi.Plus.Controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Bodhi.Plus.Model.BikeModel;
import com.example.Bodhi.Plus.ServiceInt.BikeService;

@RestController
@RequestMapping(value="/Bike")
@CrossOrigin("*")
public class ProductController{
	@Autowired
	private BikeService bikeService;
	
	@GetMapping(value="/getall")
	private ResponseEntity<Object> getBike() 
	{
		List<BikeModel> bikeList = bikeService.getBike();
		return new ResponseEntity<>(bikeList, HttpStatus.OK);
	}

	@GetMapping(value="/getbyid/{bikeId}")
	private ResponseEntity<Object> getProductbyid(@PathVariable int bikeId) 
	{
		boolean isBikeExistbyid = bikeService.isBikeExistbyid(bikeId);
		if (isBikeExistbyid)
		{
		BikeModel bikeModel = bikeService.getBikebyid(bikeId);
		return new ResponseEntity<>(bikeModel, HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<>("ID not found",HttpStatus.OK);
		}
	}
	
	@GetMapping(value="/getbyname/{bikeName}")
	private ResponseEntity<Object> getBikebyname(@PathVariable String bikeName) 
	{
		List<BikeModel> bikeModel = bikeService.getBikebyname(bikeName);
		return new ResponseEntity<>(bikeModel, HttpStatus.OK);
	}
	
	
	
	
	@PostMapping(value="/add")
	public String createBike(@RequestBody BikeModel bikeModel)
	{
		boolean isBikeExist = bikeService.isBikeExist(bikeModel.getBikeName());
		if(isBikeExist)
			return "Bike exists already";
		else {
		bikeModel = bikeService.createBike(bikeModel);
		return "Bike added";}
	}
	
	
	@DeleteMapping(value="/delete")
	public ResponseEntity<Object> deleteBike(@RequestParam int bikeId)
	{
			bikeService.deleteBike(bikeId);
			return new ResponseEntity<>("R.I.P."
					+ "\nCause of Death : BikePageModel Deletion", HttpStatus.OK);
	}
	
	
	@PutMapping(value="/edit/{bikeId}")
	public ResponseEntity<Object> updateBike(@PathVariable int bikeId, @RequestBody BikeModel bikeModel)
	{
			bikeModel.setBikeId(bikeId);
			bikeService.updateBike(bikeModel);
			return new ResponseEntity<>("BikePageModel details are updated successsfully !", HttpStatus.OK);
	}
		
	
}