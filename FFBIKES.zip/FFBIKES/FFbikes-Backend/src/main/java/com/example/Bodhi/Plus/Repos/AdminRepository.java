package com.example.Bodhi.Plus.Repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Bodhi.Plus.Model.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long>{
	
}
