package com.example.Bodhi.Plus.ServiceInt;

import java.util.List;

import com.example.Bodhi.Plus.Model.BikeModel;

public interface BikeService{

	public abstract List<BikeModel> getBike();

	public abstract BikeModel createBike(BikeModel bikeModel);

	public abstract void updateBike(BikeModel bikeModel);

	public abstract void deleteBike(Integer bikeId);

	public abstract boolean isBikeExist(String bikeName);

	public abstract boolean isBikeExistbyid(int bikeId);

    public abstract BikeModel getBikebyid(int bikeId);

    public abstract List<BikeModel> getBikebyname(String bikeName);
	
}