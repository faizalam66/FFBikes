package com.example.Bodhi.Plus.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Bodhi.Plus.Model.BikeModel;
import com.example.Bodhi.Plus.Repos.BikeRepo;
import com.example.Bodhi.Plus.ServiceInt.BikeService;

@Service
public class BikeServiceInt implements BikeService{
	
	@Autowired
	private BikeRepo bikeRepo;

	@Override
	public List<BikeModel> getBike() {
		return (List<BikeModel>)bikeRepo.findAll();
	}

	@Override
	public BikeModel createBike(BikeModel bikeModel) {
		return bikeRepo.save(bikeModel);
	}

	@Override
	public void deleteBike(Integer bikeId) {
		bikeRepo.deleteById(bikeId);
	}

	@Override
	public void updateBike(BikeModel bikeModel) {
		bikeRepo.save(bikeModel);
	}

	@Override
	public boolean isBikeExist(String bikeName) {
		return bikeRepo.existsByBikeNameIgnoreCase(bikeName);
	}

	@Override
	public boolean isBikeExistbyid(int bikeId) {
		return bikeRepo.existsById(bikeId);
	}

	@Override
	public BikeModel getBikebyid(int bikeId) {
		Optional<BikeModel> optional = bikeRepo.findById(bikeId);
		BikeModel bikeModel = optional.get();
		return bikeModel;
	}
	
	@Override
	public List<BikeModel> getBikebyname(String bikeName) 
	{
		return (List<BikeModel>) bikeRepo.findByBikeNameContainingIgnoreCase(bikeName);
	}
}