package com.example.Bodhi.Plus.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Bike")
public class BikeModel{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bikeId;
	private String bikeName;
	private String bikeUrl;
	private float bikeRate;
	private float bikeModel;
	public int getBikeId() {
		return bikeId;
	}
	public void setBikeId(int bikeId) {
		this.bikeId = bikeId;
	}
	public String getBikeName() {
		return bikeName;
	}
	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}
	public String getBikeUrl() {
		return bikeUrl;
	}
	public void setBikeUrl(String bikeUrl) {
		this.bikeUrl = bikeUrl;
	}
	public float getBikeRate() {
		return bikeRate;
	}
	public void setBikeRate(float bikeRate) {
		this.bikeRate = bikeRate;
	}
	public float getBikeModel() {
		return bikeModel;
	}
	public void setBikeModel(float bikeModel) {
		this.bikeModel = bikeModel;
	}
	@Override
	public String toString() {
		return "BikeModel [bikeId=" + bikeId + ", bikeName=" + bikeName + ", bikeUrl=" + bikeUrl + ", bikeRate="
				+ bikeRate + ", bikeModel=" + bikeModel + "]";
	} 
	
	public BikeModel(int bikeId, String bikeName, String bikeUrl, float bikeRate, float bikeModel,
			String availability) {
		super();
		this.bikeId = bikeId;
		this.bikeName = bikeName;
		this.bikeUrl = bikeUrl;
		this.bikeRate = bikeRate;
		this.bikeModel = bikeModel;
	}
	public BikeModel()
	{
		
	}
}
	
	
//	public String isAvailability() {
//		return availability;
//	}
//	public void setAvailability(String availability) {
//		this.availability = availability;
//	}
//	public int getProductId() {
//		return productId;
//	}
//	public void setProductId(int productId) {
//		this.productId = productId;
//	}
//	public String getProductName() {
//		return productName;
//	}
//	public void setProductName(String productName) {
//		this.productName = productName;
//	}
//	public String getProductUrl() {
//		return productUrl;
//	}
//	public void setProductUrl(String productUrl) {
//		this.productUrl = productUrl;
//	}
//	public float getProductRate() {
//		return productRate;
//	}
//	public void setProductRate(float productRate) {
//		this.productRate = productRate;
//	}
//	public String getProductStrip() {
//		return productStrip;
//	}
//	public void setProductStrip(String productStrip) {
//		this.productStrip = productStrip;
//	}
//	
//	@Override
//	public String toString() {
//		return "ProductModel [ProductId=" + productId + ", productName=" + productName + ", productUrl=" + productUrl
//				+ ", productRate=" + productRate + ", productStrip=" + productStrip + "]";
//	}
//}