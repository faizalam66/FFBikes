package com.example.Bodhi.Plus.Repos;

import org.springframework.data.repository.CrudRepository;

import java.util.List;
import com.example.Bodhi.Plus.Model.BikeModel;

public interface BikeRepo extends CrudRepository<BikeModel, Integer>
{

	boolean existsByBikeNameIgnoreCase(String bikeName);

    List<BikeModel> findByBikeNameContainingIgnoreCase(String bikeName);
	
}