package com.example.Bodhi.Plus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BodhiPlusApplication {

	public static void main(String[] args) {
		SpringApplication.run(BodhiPlusApplication.class, args);
	}

}
