package com.example.Bodhi.Plus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BodhiPlusApplicationTests {

	@Test
	void contextLoads() {
	}

}
