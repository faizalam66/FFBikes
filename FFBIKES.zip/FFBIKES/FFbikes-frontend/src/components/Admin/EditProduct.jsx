import './EditProduct.css'
import { TextField } from '@mui/material'
import { useStates } from '../../States';
import { RiDeleteBinLine } from 'react-icons/ri'
import axios from '../../axios';
import { useEffect, useState } from 'react';

const EditBike = ({ show }) => {
    const { getAllBikes,editbike } = useStates();

    const [bikeid, setBikeid] = useState("");
    const [bikename, setBikename] = useState("");
    const [bikerate, setBikerate] = useState("");
    const [bikeurl, setBikeurl] = useState("");
    const [bikemodel, setBikemodel] = useState("");

    useEffect(() => {
      setBikeid(editbike?.bikeId)
      setBikename(editbike?.bikeName)
      setBikerate(editbike?.bikeRate)
      setBikeurl(editbike?.bikeUrl)
      setBikemodel(editbike?.bikeModel)
    }, [editbike]);

    const editfromDB = () => {
      const bikeeditDetails = {
        bikeName:bikename,
        bikeRate:bikerate,
        bikeUrl:bikeurl,
        bikeModel:bikemodel
      }
      axios.put(`/Bike/edit/${bikeid}`,bikeeditDetails)
      .then((response)=>{
        console.log(response);
        getAllBikes();
      });
  };

  
  return (
    <>
     <div className='edit-page'>
          <div className='edit-box'>

            <div className='edit-div'>
              <span className='edit-text'><b>Edit Bike</b></span>
            </div>

            <form onSubmit={()=> show(false)}>
            <div className='canceleditprod-div'>
              <button  className='canceleditprod-btn'><b><RiDeleteBinLine/></b></button>
            </div>
            </form>

            <form onSubmit={()=> show(false)}>
            <div className='editprodname-div'>
            <TextField className='editprodname-in' label="Bike Name" variant="standard" value={bikename}
              onChange={(e) => setBikename(e.target.value)}/>
            </div>

            <div className='editprodrate-div'>
            <TextField className='editprodrate-in' label="Bike Rate" type='number' variant="standard" value={bikerate}
              onChange={(e) => setBikerate(e.target.value)}/>
            </div>

            <div className='editprodurl-div'>
            <TextField className='editprodurl-in'  label="Bike URL" variant="standard" value={bikeurl}
              onChange={(e) => setBikeurl(e.target.value)}/>
            </div>

            <div className='editprodshop-div'>
            <TextField className='editprodshop-in'  label="Bike URL" variant="standard" value={bikemodel}
              onChange={(e) => setBikemodel(e.target.value)}/>
            </div>

            <div className='editprod-div'>
              <button className='editprod-btn' onClick={editfromDB}>Update Bike</button>
            </div>
            </form>
           </div> 
        </div>
    </>
  );
};
export default EditBike; 