import './AddProduct.css'
import { TextField } from '@mui/material'
import { useStates } from '../../States';
import { RxCrossCircled } from 'react-icons/rx'

const AddProduct = ({ show }) => {

  const { setBikename, setBikerate, setBikeurl, SendtobikeDB, setBikemodel } = useStates();
  return (
    <>
      <div className='add-page'>
        <div className='add-box'>

          <div className='add-div'>
            <span className='add-text'><b>Add New Bike</b></span>
          </div>

          <form onSubmit={() => show(false)}>
            <div className='canceladdprod-div'>
              <button className='canceladdprod-btn'><b><RxCrossCircled/></b></button>
            </div>
          </form>

          <form onSubmit={SendtobikeDB}>

            <div className='prodname-div'>
              <TextField className='prodname-in' label="Bike Name" variant="standard" required
                onChange={(e) => setBikename(e.target.value)} />
            </div>

            <div className='prodrate-div'>
              <TextField className='prodrate-in' type='number' label="Bike Price" variant="standard" required
                onChange={(e) => setBikerate(e.target.value)} />
            </div>

            <div className='produrl-div'>
              <TextField className='produrl-in' label="Bike URL" variant="standard" required
                onChange={(e) => setBikeurl(e.target.value)} />
            </div>

            <div className='prodshop-div'>
              <TextField className='prodshop-in' label="Bike Model" variant="standard" required
                onChange={(e) => setBikemodel(e.target.value)} />
            </div>

            <div className='addprod-div'>
              <button className='addprod-btn' onClick={() => show(false)}>Add Bike</button>
            </div>

          </form>
        </div>
      </div>
    </>
  );
};
export default AddProduct;