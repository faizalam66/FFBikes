import '../Home/Home.css';
import { useStates } from '../../States';
import { useEffect } from 'react';
import { motion } from "framer-motion";
import { MdAddBox,MdEdit } from "react-icons/md"
import AddBike from './AddBike';
import EditBike from './EditBike';
import { RiDeleteBinLine } from 'react-icons/ri';
import { Tooltip } from '@mui/material';

function AdminHome() {
    const { getAllBikes,bike,deletefromDB,addbike,setaddbike,editbike,seteditbike,seteditBike } = useStates();

    useEffect(() => {
        getAllBikes();
        // eslint-disable-next-line
    },[]);

    const geteditdata = (bike) => {
        fetch(`http://localhost:1403/Bike/getbyid/${bike.bikeId}`)
        .then((res) => res.json())
        .then((result) => {
            seteditBike(result);
            console.log(result);
        });
    };
  
    return (
        <>
         <motion.div className="product-page">
            
            <button  className='addpage-linkbtn' onClick={() => setaddbike(true)}>
              <span className='addpage-link'><MdAddBox/></span>
             {addbike && <AddBike show={setaddbike}/>}
            </button>
             {editbike && <EditBike show={seteditbike}/>}
             
           {bike.map((bike,i) => {
            return(
                <>
                <motion.div layout key={i} className="admin-div">

                <Tooltip title="Edit"  placement="right" arrow>
                    <button className='edit-btn' 
                    onClick={()=> {
                        seteditbike(true)
                        geteditdata(bike)
                    }}>
                        <MdEdit/></button>
                </Tooltip>
                
                <Tooltip title="Delete"  placement="bottom" arrow>
                    <button className='delete-btn' onClick={() =>{deletefromDB(bike.bikeId)}}
                    ><RiDeleteBinLine/></button>
                </Tooltip>

                    <img className='product-img' src={bike.bikeUrl} alt=""></img>
                    <span className='product-name'><b>{bike.bikeName}</b></span>
                    <span className='product-rate'><b>Model: {bike.bikeModel}</b></span>
                    <button className='product-shop'>Rs.{bike.bikeRate}.00</button>
                </motion.div>
                </>
            )
        })}
        </motion.div>
        </>
    );
};
export default AdminHome;