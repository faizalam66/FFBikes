import './Home.css';
import { useStates } from '../../States';
import { useEffect } from 'react';
import { motion } from "framer-motion";
function Home() {
    const { getAllBikes,bike} = useStates();

    useEffect(() => {
        getAllBikes();
        // eslint-disable-next-line
    },[]);
  
    return (
        <>
         <motion.div className="product-page">
           {bike.map((bike,i) => {
            return(
                <>
                <motion.div layout key={i} className="product-div">
                    {/* <span className='product-id'>{product.productId}</span> */}
                    {/* <img alt='edit button' className='edit-btn'
                    src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBqvw9fFq2uIc9H7kVCAz964W5Lw9CvK7BrQ&usqp=CAU'></img> */}
                    <img className='product-img' src={bike.bikeUrl} alt=""></img>
                    <span className='product-name'><b>{bike.bikeName}</b></span>
                    <span className='product-rate'><b>Model: {bike.bikeModel} </b></span>
                    <button className='product-shop'>Rs.{bike.bikeRate}.00</button>
                </motion.div>
                </>
            )
        })}
        </motion.div>
        </>
    );
};
export default Home;